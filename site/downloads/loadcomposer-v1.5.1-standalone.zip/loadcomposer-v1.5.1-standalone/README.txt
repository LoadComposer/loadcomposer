LoadComposer v1.5.1 — Standalone package

Open loadcomposer-v1.5.1-standalone.html directly in a modern browser. It works offline through
file://, requires no installation, and processes entered data locally in the
browser.

This release is distributed under the LoadComposer Community License 1.0.
Ordinary internal business use is permitted. Monetization, SaaS, monetized hosting,
white-label distribution, and the other reserved uses described in
the license require a separate commercial license.

Official repository: https://github.com/LoadComposer/loadcomposer
Official site: https://loadcomposer.com/
Commercial licensing: licensing@loadcomposer.com

The software is provided "AS IS", without warranty. Version 1.5.1 performs
indicative geometric planning only: it does not verify weight, balance, axle
loads, floor loads, securing, stability, safety, legal compliance, or actual
equipment tolerances. Always verify the real load and equipment operationally.

Read LICENSE, LICENSE.it.md, and NOTICE before use. The English LICENSE is the
controlling legal text; LICENSE.it.md is an informational translation.
